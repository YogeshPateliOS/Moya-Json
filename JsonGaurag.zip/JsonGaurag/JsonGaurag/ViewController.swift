//
//  ViewController.swift
//  JsonGaurag
//
//  Created by Yogesh Patel on 11/17/19.
//  Copyright © 2019 Yogesh Patel. All rights reserved.
//

import UIKit
import Moya

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
//        getData()
       // getPostRequest()
        uploadImage()
        // Do any additional setup after loading the view.
    }

    private func getData(){
        let provider = MoyaProvider<PlaceHolderService>()
        
        provider.request(.placeholder) { (result) in
            switch result{
            case .success(let response):
                print(String.init(data: response.data, encoding: .utf8))
                break
            case .failure(let error):
                print(error)
                
            }
        }
    }
    
    private func getPostRequest(){
        let params: [String: Any] = ["userID": 1, "title": "my title", "body": "my body"]
        
        let provider = MoyaProvider<PlaceHolderService>()
        
        provider.request(.placeholderPost(params: params)) { (result) in
            switch result{
            case .success(let response):
                print(String.init(data: response.data, encoding: .utf8))
                    break
                case .failure(let error):
                    print(error)
                    
                }
            }
    }
    
    private func uploadImage(){
        
         
         let provider = MoyaProvider<PlaceHolderService>()
        let data = #imageLiteral(resourceName: "p9.png").jpegData(compressionQuality: 1)!
        provider.request(.imageUpload(photo: data)) { (result) in
            switch result{
            case .success(let response):
                print(String.init(data: response.data, encoding: .utf8))
                    break
                case .failure(let error):
                    print(error)
                    
                }
        }
        /*
         
         */
     }
    
    

}

